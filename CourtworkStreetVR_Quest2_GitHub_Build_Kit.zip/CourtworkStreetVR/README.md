# Courtwork Street VR — Meta Quest 2

Godot 4.7.2 prototype targeting standalone Android VR on Meta Quest 2.

## Current prototype

- OpenXR startup and left/right Meta Touch controller action map.
- Small indoor practice court, hoop, backboard, rim collision and score trigger.
- Physics basketball with controller grab, velocity-based release and scoring.
- In-headset trainer settings for shot power, shot assistance and dribble-bounce assistance.
- Compatibility renderer and 90 Hz physics tick target.

This is an early single-player practice prototype. It does not yet include online multiplayer, opposing players, avatars, cosmetics, a career mode, or physical-headset QA.

## Build the Quest 2 APK in GitHub

1. Put the contents of this build kit into the root of your GitHub repository (keep the `.github/workflows` folder).
2. Open the repository's **Actions** tab.
3. Select **Build Courtwork Street VR for Quest 2** and choose **Run workflow** on `main`.
4. Wait for the run to finish successfully.
5. Open that run and download the `CourtworkStreetVR-Quest2-APK` artifact.
6. Extract the artifact ZIP to get `CourtworkStreetVR-Quest2.apk`.

The workflow installs Godot 4.7.2 and its matching Android export templates, OpenJDK 17 and the Android SDK. It exports an ARM64 Android APK with OpenXR enabled and signs it using a temporary debug key. It is for local testing/sideloading, not a store release. Rebuilding uses a new debug signing key, so an earlier build may need to be uninstalled before installing a newer one.

## Quest 2 controls

- Right grip: hold to grab the ball; release to throw.
- Right B: toggle trainer panel.
- Right A: increase shot power.
- Left Y: decrease shot power.
- Left X: toggle shot assist.
- Left thumbstick click: toggle dribble-bounce assistance.
- Left grip: reset basketball.

Keep the Quest guardian/boundary enabled and clear the play area before testing. A successful Android export does not prove runtime behavior on a physical headset; test the APK on Quest 2.
