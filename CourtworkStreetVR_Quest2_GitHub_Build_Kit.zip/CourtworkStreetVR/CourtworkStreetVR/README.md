# Courtwork Street VR — Quest 2 Prototype

**Project type:** Godot 4.x, Android/OpenXR, single-player practice-court prototype  
**Target headset:** Meta Quest 2  
**Status:** Source project prepared; not yet exported or tested on a physical headset.

## Included in this prototype

- OpenXR scene structure for a head-mounted display with left/right tracked controllers.
- Compact indoor practice court with a hoop, backboard, rim collision, and score trigger.
- Rigid-body basketball with pickup, hand-following while held, and velocity-based release/throwing.
- Score and field-goal percentage display.
- In-headset trainer panel with shot-power, shot-assist, and dribble-bounce-assist settings.
- Lightweight Compatibility renderer settings and 90 Hz physics tick target.
- Desktop preview controls for basic testing without a headset.

This is the first playable slice. It does **not** include online multiplayer, avatars, cosmetics, a full career system, or a production-ready store build.

## Quest 2 controller controls

| Action | Controller input |
|---|---|
| Grab the basketball | Hold right grip/squeeze |
| Throw | Release right grip/squeeze |
| Open/close trainer panel | Right B |
| Increase shot power | Right A |
| Decrease shot power | Left Y |
| Toggle shot assist | Left X |
| Toggle dribble-bounce assist | Press left thumbstick |
| Reset ball | Left grip/squeeze |

Walk around your real play area to move around the practice court. Keep the headset guardian/boundary enabled and clear the play space before playing.

## Desktop preview controls

- **W / A / S / D:** move
- **Mouse:** look around (left click captures the mouse)
- **Hold left mouse button:** pick up the ball when close enough
- **Release left mouse button:** throw
- **R:** reset ball
- **Tab:** open/close trainer panel
- **Esc:** release mouse capture

## Opening the project

1. Open the project folder in **Godot 4.7.x Standard** (the project uses GDScript, not C#).
2. Allow Godot to import the project.
3. For desktop preview, press **F5** to run the project, or select `scenes/main.tscn` and press **F6** to run that scene.
4. For Quest 2, use an Android export preset with **XR Mode = OpenXR**, **ARM64** enabled, and the Compatibility renderer. The project already points OpenXR at `openxr_action_map.tres`.

## Android/Quest export requirements

Godot's Android exporter requires the Android export templates and an Android build toolchain. The official Godot Android export guide lists OpenJDK 17 and the Android SDK (normally installed through Android Studio). The OpenXR Android deployment guide documents enabling an Android preset, choosing OpenXR, and using Quest developer mode/ADB for deployment.

The Android export preset and signed APK have **not** been generated in this workspace. This archive is the Godot source project, not an APK. The project has not yet been run through the Godot editor or tested on Quest 2 hardware, so the first export should be treated as a prototype build and tested in a clear, supervised play space.

## Official docs

- Godot Android XR deployment: https://docs.godotengine.org/en/latest/tutorials/xr/deploying_to_android.html
- Godot XR setup: https://docs.godotengine.org/en/stable/tutorials/xr/setting_up_xr.html
- Godot Android export: https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_android.html
- Meta OpenXR support for Quest 2: https://developers.meta.com/vr/documentation/native/android/mobile-openxr/
